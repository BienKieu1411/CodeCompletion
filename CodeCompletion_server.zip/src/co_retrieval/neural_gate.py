"""Adaptive retrieval gate (neural version).

The gate receives the *query embedding* produced by the retriever encoder and
outputs a scalar probability g ∈ [0, 1] indicating whether cross-file
retrieval is likely to help for the current completion.  In the main
pipeline, this gate is trained from retrieve-vs-stop utility labels rather
than from retrieve-vs-retrieve DPO pairs.

Design
------
* **MLP backbone** — two-layer MLP with GELU activation and dropout.
* **Log-probability interface** — ``log_probs`` returns both
  ``log P(continue|q)`` and ``log P(stop|q)`` for diagnostics or explicit
  joint-scoring ablations.
* **Entropy regularisation** — discourages gate collapse to always-on/off.
"""

from __future__ import annotations

import logging
from typing import Dict, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F

logger = logging.getLogger(__name__)


class NeuralGate(nn.Module):
    """Adaptive retrieval gate operating on dense query embeddings.

    Parameters
    ----------
    input_dim : int
        Dimension of the query embedding (must match retriever output).
    hidden_dim : int
        Hidden layer size.
    dropout : float
        Dropout rate between MLP layers.
    entropy_weight : float
        Weight for the entropy regularisation term.
    """

    def __init__(
        self,
        input_dim: int = 768,
        hidden_dim: int = 256,
        dropout: float = 0.1,
        entropy_weight: float = 0.01,
        feature_dim: int = 0,
    ) -> None:
        super().__init__()
        self.entropy_weight = entropy_weight
        self.input_dim = input_dim
        self.feature_dim = feature_dim
        total_input_dim = input_dim + feature_dim

        self.mlp = nn.Sequential(
            nn.Linear(total_input_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )

        # Initialise bias towards retrieval (safer default).
        with torch.no_grad():
            self.mlp[-1].bias.fill_(0.2)

    # ── Forward ───────────────────────────────────────────────────────────

    def _with_features(
        self,
        query_vec: torch.Tensor,
        extra_features: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if self.feature_dim <= 0:
            return query_vec
        if extra_features is None:
            feature_shape = query_vec.shape[:-1] + (self.feature_dim,)
            extra_features = torch.zeros(
                feature_shape,
                dtype=query_vec.dtype,
                device=query_vec.device,
            )
        else:
            extra_features = extra_features.to(
                dtype=query_vec.dtype,
                device=query_vec.device,
            )
            if query_vec.dim() == 1 and extra_features.dim() == 2:
                extra_features = extra_features.squeeze(0)
            if query_vec.dim() == 2 and extra_features.dim() == 1:
                extra_features = extra_features.unsqueeze(0).expand(
                    query_vec.shape[0], -1
                )
        if extra_features.shape[-1] != self.feature_dim:
            raise ValueError(
                f"Expected {self.feature_dim} gate features, got "
                f"{extra_features.shape[-1]}"
            )
        return torch.cat([query_vec, extra_features], dim=-1)

    def forward(
        self,
        query_vec: torch.Tensor,
        extra_features: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """Compute gate probability g = P(continue/retrieve | query).

        Parameters
        ----------
        query_vec : (*, input_dim)

        Returns
        -------
        g : (*, 1) tensor with values in [0, 1].
        """
        return torch.sigmoid(self.mlp(self._with_features(query_vec, extra_features)))

    # ── Log-probabilities for optional joint scoring ──────────────────────

    def log_probs(
        self,
        query_vec: torch.Tensor,
        extra_features: torch.Tensor | None = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Return (log P_gate(continue|q), log P_gate(stop|q)).

        Available for optional joint scoring:
            S(q, C_retrieved) = log P_gate(continue|q) + mean(sim(q, snippet_i))
            S(q, C_stop)      = log P_gate(stop|q)

        The main training loop keeps gate supervision separate.
        """
        logit = self.mlp(self._with_features(query_vec, extra_features))
        log_continue = F.logsigmoid(logit)          # log σ(x)
        log_stop = F.logsigmoid(-logit)              # log(1 - σ(x)) = log σ(-x)
        return log_continue.squeeze(-1), log_stop.squeeze(-1)

    # ── Decision ──────────────────────────────────────────────────────────

    def should_retrieve(
        self,
        query_vec: torch.Tensor,
        extra_features: torch.Tensor | None = None,
        threshold: float = 0.5,
    ) -> bool:
        """Deterministic decision for inference."""
        if isinstance(extra_features, (float, int)):
            threshold = float(extra_features)
            extra_features = None
        with torch.no_grad():
            g = self.forward(query_vec, extra_features)
        return bool(g.item() >= threshold)

    # ── Loss ──────────────────────────────────────────────────────────────

    def gate_loss(
        self,
        g: torch.Tensor,
        retrieve_is_better: bool,
    ) -> torch.Tensor:
        """Binary cross-entropy + entropy regularisation.

        Parameters
        ----------
        g : scalar tensor — gate output probability.
        retrieve_is_better : bool — supervision label from NLL comparison.
        """
        label = torch.tensor(
            [1.0 if retrieve_is_better else 0.0],
            device=g.device,
            dtype=g.dtype,
        )
        g_clamped = g.view(-1).clamp(1e-7, 1.0 - 1e-7)

        bce = F.binary_cross_entropy(g_clamped, label)

        # Entropy regularisation: maximise H(g) to prevent collapse
        entropy = -(
            g_clamped * torch.log(g_clamped)
            + (1.0 - g_clamped) * torch.log(1.0 - g_clamped)
        )
        return bce - self.entropy_weight * entropy.mean()

    # ── Monitoring ────────────────────────────────────────────────────────

    def gate_stats(self, query_vecs: torch.Tensor) -> Dict[str, float]:
        """Compute gate statistics over a batch for monitoring."""
        with torch.no_grad():
            gs = self.forward(query_vecs).squeeze(-1)
        return {
            "mean": float(gs.mean()),
            "std": float(gs.std()) if gs.numel() > 1 else 0.0,
            "retrieve_rate": float((gs >= 0.5).float().mean()),
        }
