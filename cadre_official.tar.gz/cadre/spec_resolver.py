"""
spec_resolver.py - Target Specification Resolver for CADRE-DraftSpec
Resolves exact function, method, and class interfaces from repository files,
extracting canonical PEP 484 / Java interface stubs (L_stub), docstring summaries,
and sanitized call-sites with Class Hierarchy Preservation.
"""

import ast
import re
from typing import Any, Dict, List, Optional
from .intent_parser import strip_method_affixes


class TargetSpecResolver:
    """
    Scans repository files to resolve exact target interfaces and format them
    into canonical structural contracts.
    """

    @staticmethod
    def resolve_specification(
        language: str,
        pool_files: List[Dict[str, Any]],
        candidate_tokens: List[str],
        receiver: str = "",
        retrieved_chunks: Optional[List[Dict[str, Any]]] = None,
    ) -> str:
        """
        Resolves the target specification and formats it into a fenced contract.
        
        Args:
            language: Programming language ('python' or 'java').
            pool_files: List of file dictionaries with keys 'path' and 'text'.
            candidate_tokens: List of target function/class names and keywords.
            receiver: Receiver object name if available.
            retrieved_chunks: Existing retrieved chunks (for redundancy gating).
            
        Returns:
            Fenced target specification contract string, or empty string if not applicable.
        """
        if not candidate_tokens:
            return ""

        # Gating: If primary callee already has its full definition in top retrieved chunks,
        # avoid injecting an overriding duplicate stub.
        if retrieved_chunks:
            top_text = " ".join((c.get("code") or c.get("text") or "") for c in retrieved_chunks[:3])
            primary = candidate_tokens[0]
            if re.search(rf"\b(?:def|class|public|protected|private)\s+{re.escape(primary)}\s*[\(:]", top_text):
                return ""

        comment = "#" if language == "python" else "//"
        best_candidate: Optional[Dict[str, Any]] = None
        best_score = -1.0

        for pf in pool_files:
            fpath = pf.get("path", "")
            text = pf.get("text", "")
            if not text.strip():
                continue
            lines = text.splitlines()

            if language == "python":
                ast_candidates = []
                try:
                    tree = ast.parse(text)
                    for item in tree.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            fname = item.name
                            if not fname.startswith("__"):
                                sig_parts = []
                                for a in item.args.args:
                                    ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
                                    sig_parts.append(f"{a.arg}{ann}")
                                if item.args.vararg:
                                    sig_parts.append(f"*{item.args.vararg.arg}")
                                for a in item.args.kwonlyargs:
                                    ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
                                    sig_parts.append(f"{a.arg}{ann}")
                                if item.args.kwarg:
                                    sig_parts.append(f"**{item.args.kwarg.arg}")

                                ret = f" -> {ast.unparse(item.returns)}" if item.returns else ""
                                sig = f"def {fname}({', '.join(sig_parts)}){ret}: ..."
                                doc = ast.get_docstring(item)
                                doc_sum = doc.splitlines()[0].strip() if doc else ""
                                ast_candidates.append({
                                    "name": fname, "class_name": "", "sig": sig, "doc": doc_sum
                                })

                    for node in ast.walk(tree):
                        if isinstance(node, ast.ClassDef):
                            cname = node.name
                            is_enum = any("Enum" in ast.unparse(b) for b in node.bases)
                            enum_members = []
                            for item in node.body:
                                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                                    mname = item.name
                                    if not (mname.startswith("__") and mname != "__init__"):
                                        sig_parts = []
                                        for a in item.args.args:
                                            ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
                                            sig_parts.append(f"{a.arg}{ann}")
                                        if item.args.vararg:
                                            sig_parts.append(f"*{item.args.vararg.arg}")
                                        for a in item.args.kwonlyargs:
                                            ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
                                            sig_parts.append(f"{a.arg}{ann}")
                                        if item.args.kwarg:
                                            sig_parts.append(f"**{item.args.kwarg.arg}")

                                        ret = f" -> {ast.unparse(item.returns)}" if item.returns else ""
                                        inner_sig = f"def {mname}({', '.join(sig_parts)}){ret}: ..."
                                        sig = f"class {cname}:\n        {inner_sig}"
                                        doc = ast.get_docstring(item)
                                        doc_sum = doc.splitlines()[0].strip() if doc else ""
                                        ast_candidates.append({
                                            "name": mname, "class_name": cname, "sig": sig, "doc": doc_sum
                                        })
                                elif isinstance(item, ast.Assign) and is_enum:
                                    for target in item.targets:
                                        if isinstance(target, ast.Name):
                                            enum_members.append(target.id)

                            if is_enum and enum_members:
                                enum_sig = f"class {cname}(Enum): " + ", ".join(f"{m} = ..." for m in enum_members[:10])
                                ast_candidates.append({
                                    "name": cname, "class_name": cname, "sig": enum_sig, "doc": "Enum definition"
                                })
                                for m in enum_members[:10]:
                                    ast_candidates.append({
                                        "name": m, "class_name": cname, "sig": f"{cname}.{m} = ...", "doc": f"Enum member of {cname}"
                                    })
                except Exception:
                    ast_candidates = []

                if ast_candidates:
                    for cand_info in ast_candidates:
                        def_name = cand_info["name"]
                        score = 0.0
                        for cand in candidate_tokens:
                            if cand == def_name:
                                score = max(score, 2.5)
                            elif strip_method_affixes(cand) and strip_method_affixes(cand) == strip_method_affixes(def_name):
                                score = max(score, 2.0)
                            elif cand.lower() == def_name.lower():
                                score = max(score, 1.8)
                            elif cand.lower() in def_name.lower():
                                score = max(score, 1.0)

                        if score > best_score and score >= 1.0:
                            best_score = score
                            best_candidate = {
                                "file": fpath,
                                "name": def_name,
                                "class_name": cand_info["class_name"],
                                "sig": cand_info["sig"],
                                "doc": cand_info["doc"],
                            }
                else:
                    for idx, line in enumerate(lines):
                        s = line.strip()
                        if s.startswith("def ") or s.startswith("async def "):
                            m = re.match(r"(?:async\s+)?def\s+([A-Za-z_][A-Za-z0-9_]*)", s)
                            if m:
                                def_name = m.group(1)
                                score = 0.0
                                for cand in candidate_tokens:
                                    if cand == def_name:
                                        score = max(score, 2.5)
                                    elif strip_method_affixes(cand) and strip_method_affixes(cand) == strip_method_affixes(def_name):
                                        score = max(score, 2.0)
                                    elif cand.lower() == def_name.lower():
                                        score = max(score, 1.8)
                                    elif cand.lower() in def_name.lower():
                                        score = max(score, 1.0)

                                if score > best_score and score >= 1.0:
                                    sig_lines = [s]
                                    j = idx
                                    while ":" not in sig_lines[-1] and j + 1 < len(lines):
                                        j += 1
                                        sig_lines.append(lines[j].strip())
                                    full_sig = " ".join(" ".join(sig_lines).split())
                                    if ":" in full_sig:
                                        full_sig = full_sig.split(":")[0] + ": ..."

                                    enclosing_class = ""
                                    for k in range(idx - 1, max(-1, idx - 60), -1):
                                        pl = lines[k].strip()
                                        if pl.startswith("class "):
                                            m_cls = re.match(r"class\s+([A-Za-z_][A-Za-z0-9_]*)", pl)
                                            if m_cls:
                                                enclosing_class = m_cls.group(1)
                                                break

                                    if enclosing_class:
                                        full_sig = f"class {enclosing_class}:\n        {full_sig}"

                                    doc = ""
                                    if j + 1 < len(lines):
                                        next_l = lines[j + 1].strip()
                                        if '"""' in next_l or "'''" in next_l:
                                            doc = next_l.replace('"""', '').replace("'''", '').strip()
                                            if not doc and j + 2 < len(lines):
                                                doc = lines[j + 2].replace('"""', '').replace("'''", '').strip()

                                    best_score = score
                                    best_candidate = {
                                        "file": fpath,
                                        "name": def_name,
                                        "class_name": enclosing_class,
                                        "sig": full_sig,
                                        "doc": doc[:120],
                                    }

            else:  # Java
                for idx, line in enumerate(lines):
                    s = line.strip()
                    if (s.startswith("public ") or s.startswith("protected ") or s.startswith("private ") or s.startswith("static ")) and "(" in s and ")" in s:
                        m = re.search(r"([A-Za-z_][A-Za-z0-9_]*)\s*\(", s)
                        if m:
                            def_name = m.group(1)
                            if def_name in ("if", "for", "while", "switch", "catch"):
                                continue
                            score = 0.0
                            for cand in candidate_tokens:
                                if cand == def_name:
                                    score = max(score, 2.5)
                                elif strip_method_affixes(cand) and strip_method_affixes(cand) == strip_method_affixes(def_name):
                                    score = max(score, 2.0)
                                elif cand.lower() == def_name.lower():
                                    score = max(score, 1.8)
                                elif cand.lower() in def_name.lower():
                                    score = max(score, 1.0)

                            if score > best_score and score >= 1.0:
                                sig = s.split("{")[0].strip()
                                if not sig.endswith(";"):
                                    sig += ";"

                                enclosing_class = ""
                                for k in range(idx - 1, max(-1, idx - 60), -1):
                                    pl = lines[k].strip()
                                    if "class " in pl or "interface " in pl:
                                        m_cls = re.search(r"(?:class|interface)\s+([A-Za-z_][A-Za-z0-9_]*)", pl)
                                        if m_cls:
                                            enclosing_class = m_cls.group(1)
                                            break

                                if enclosing_class:
                                    sig = f"interface {enclosing_class} {{\n        {sig}\n    }}"

                                best_score = score
                                best_candidate = {
                                    "file": fpath,
                                    "name": def_name,
                                    "class_name": enclosing_class,
                                    "sig": sig,
                                    "doc": "",
                                }

        if not best_candidate:
            return ""

        # Assemble the attention-anchoring banner
        banner = [
            f"{comment} ==============================================================================",
            f"{comment} <<< TARGET API SPECIFICATION (RESOLVED FROM DRAFT INTENT) >>>",
            f"{comment} Source Module: {best_candidate['file']}",
            f"{comment} Canonical Signature (L_stub):",
        ]
        for sig_l in best_candidate["sig"].splitlines():
            banner.append(f"{comment}     {sig_l}")
        if best_candidate.get("doc"):
            banner.append(f"{comment} Docstring Summary: \"\"\"{best_candidate['doc']}\"\"\"")
        banner.append(f"{comment} ==============================================================================\n\n")

        return "\n".join(banner)
