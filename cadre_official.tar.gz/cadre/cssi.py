"""
cssi.py - Context-Aware Syntactic/Semantic Interface Stub (CSSI) Builder
Backed by TypedContextTree (T_CSSI) with AST parsing, Inheritance Resolution,
and Multi-Mode Structural Linearization / Text Embedding.
"""

import ast
import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

STOP_WORDS: Set[str] = {
    "self", "this", "None", "True", "False", "def", "class", "if", "for", "while",
    "return", "import", "from", "public", "private", "protected", "static", "void",
    "int", "str", "float", "bool", "list", "dict", "set", "super", "try", "except"
}


@dataclass
class MethodNode:
    """Represents a method or function signature in the Typed Context Tree."""
    name: str
    signature: str
    docstring: Optional[str] = None
    is_inherited: bool = False
    source_class: str = ""


@dataclass
class ClassNode:
    """Represents a class node in the Typed Context Tree with inheritance links."""
    name: str
    file_path: str
    language: str
    bases: List[str] = field(default_factory=list)
    methods: Dict[str, MethodNode] = field(default_factory=dict)
    fields: Dict[str, str] = field(default_factory=dict)
    parent_classes: List["ClassNode"] = field(default_factory=list)


class TypedContextTree:
    """
    Typed Context Tree T_CSSI = (V, E, tau, lambda)
    Models classes, member methods, and cross-file inheritance dependencies.
    """
    def __init__(self):
        self.classes: Dict[str, ClassNode] = {}

    def parse_python_ast(self, file_path: str, source_code: str):
        """Extracts class definitions and signatures via Python AST."""
        try:
            tree = ast.parse(source_code)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    cname = node.name
                    bases = []
                    for b in node.bases:
                        if isinstance(b, ast.Name):
                            bases.append(b.id)
                        elif isinstance(b, ast.Attribute):
                            bases.append(ast.unparse(b))

                    cnode = ClassNode(name=cname, file_path=file_path, language="python", bases=bases)
                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            mname = item.name
                            if mname.startswith("__") and mname != "__init__":
                                continue
                            sig_parts = []
                            for a in item.args.args:
                                ann = f": {ast.unparse(a.annotation)}" if a.annotation else ""
                                sig_parts.append(f"{a.arg}{ann}")
                            ret = f" -> {ast.unparse(item.returns)}" if item.returns else ""
                            sig = f"def {mname}({', '.join(sig_parts)}){ret}"
                            doc = ast.get_docstring(item)
                            first_doc = doc.splitlines()[0].strip() if doc else None

                            cnode.methods[mname] = MethodNode(
                                name=mname,
                                signature=sig,
                                docstring=first_doc,
                                is_inherited=False,
                                source_class=cname
                            )
                    self.classes[cname] = cnode
        except Exception:
            self._parse_python_regex(file_path, source_code)

    def _parse_python_regex(self, file_path: str, source_code: str):
        """Fallback regex parser for Python files with syntax irregularities."""
        lines = source_code.splitlines()
        for i, line in enumerate(lines):
            m = re.match(r"^class\s+([A-Za-z0-9_]+)(?:\(([^)]+)\))?:", line.strip())
            if m:
                cname = m.group(1)
                bases_raw = m.group(2) or ""
                bases = [b.strip() for b in bases_raw.split(",") if b.strip()]
                cnode = ClassNode(name=cname, file_path=file_path, language="python", bases=bases)
                for k in range(i + 1, min(len(lines), i + 60)):
                    l = lines[k].strip()
                    if l.startswith("class "):
                        break
                    if l.startswith("def "):
                        mname = re.match(r"def\s+([A-Za-z0-9_]+)", l)
                        if mname and not (mname.group(1).startswith("__") and mname.group(1) != "__init__"):
                            sig = l.split(":")[0]
                            cnode.methods[mname.group(1)] = MethodNode(
                                name=mname.group(1),
                                signature=sig,
                                is_inherited=False,
                                source_class=cname
                            )
                self.classes[cname] = cnode

    def parse_java_regex(self, file_path: str, source_code: str):
        """Extracts Java classes and interfaces with extends / implements hierarchy."""
        for m in re.finditer(r"class\s+([A-Za-z0-9_]+)(?:\s+extends\s+([A-Za-z0-9_]+))?(?:\s+implements\s+([A-Za-z0-9_,\s]+))?", source_code):
            cname = m.group(1)
            bases = []
            if m.group(2): bases.append(m.group(2).strip())
            if m.group(3): bases.extend([b.strip() for b in m.group(3).split(",") if b.strip()])
            cnode = ClassNode(name=cname, file_path=file_path, language="java", bases=bases)
            idx = m.end()
            chunk = source_code[idx:idx + 4000]
            for mm in re.finditer(r"(?:public|protected|private|\s)\s+([A-Za-z0-9_<>[\]]+)\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*[{;]", chunk):
                ret_type = mm.group(1)
                mname = mm.group(2)
                params = mm.group(3)
                if mname not in ("if", "for", "while", "switch", "catch"):
                    sig = f"{ret_type} {mname}({params});"
                    cnode.methods[mname] = MethodNode(
                        name=mname,
                        signature=sig,
                        is_inherited=False,
                        source_class=cname
                    )
            self.classes[cname] = cnode

    def resolve_inheritance(self, max_depth: int = 3):
        """
        Traverses class hierarchy: pulls inherited methods into descendant nodes.
        """
        for cname, cnode in list(self.classes.items()):
            visited = set()
            curr_bases = list(cnode.bases)
            depth = 0
            while curr_bases and depth < max_depth:
                depth += 1
                next_bases = []
                for base_name in curr_bases:
                    if base_name in visited or base_name in ("object", "type", "Exception"):
                        continue
                    visited.add(base_name)
                    if base_name in self.classes:
                        parent = self.classes[base_name]
                        cnode.parent_classes.append(parent)
                        for pm_name, pm_node in parent.methods.items():
                            if pm_name not in cnode.methods:
                                cnode.methods[pm_name] = MethodNode(
                                    name=pm_name,
                                    signature=pm_node.signature,
                                    docstring=pm_node.docstring,
                                    is_inherited=True,
                                    source_class=parent.name
                                )
                        next_bases.extend(parent.bases)
                curr_bases = next_bases

    def linearize(
        self,
        target_class_names: List[str],
        mode: str = "decorated_stub",
        max_methods: int = 8,
    ) -> str:
        """
        Embeds / Linearizes the tree into text format for prompting.
        Supported modes:
        - 'decorated_stub' (Default): Code-native stub with explicit # [Inherited from Base] section.
        - 'chained_stub': Sequence of BaseClass -> ChildClass code stubs.
        - 'ascii_tree': Hierarchical ASCII tree representation (└──, ├──).
        - 'schema': JSON AST schema map.
        """
        matched = [self.classes[c] for c in target_class_names if c in self.classes]
        if not matched:
            return ""

        blocks = []
        for cnode in matched:
            comment = "#" if cnode.language == "python" else "//"

            if mode == "decorated_stub":
                local_methods = [m for m in cnode.methods.values() if not m.is_inherited]
                inherited_methods = [m for m in cnode.methods.values() if m.is_inherited]

                base_str = f"({', '.join(cnode.bases)})" if cnode.bases else ""
                lines = [f"{comment} [CSSI Scope Tree: {cnode.name}{base_str} in {cnode.file_path}]"]
                lines.append(f"class {cnode.name}{base_str}:")

                if inherited_methods:
                    lines.append(f"    {comment} --- Inherited from {', '.join(cnode.bases)} ---")
                    for m in inherited_methods[:max_methods // 2]:
                        stub_sig = m.signature + ": ..." if cnode.language == "python" else m.signature
                        lines.append(f"    {stub_sig}")
                        if m.docstring:
                            lines.append(f'        """{m.docstring}"""')

                lines.append(f"    {comment} --- Declared in {cnode.name} ---")
                for m in local_methods[:max_methods]:
                    stub_sig = m.signature + ": ..." if cnode.language == "python" else m.signature
                    lines.append(f"    {stub_sig}")
                    if m.docstring:
                        lines.append(f'        """{m.docstring}"""')

                blocks.append("\n".join(lines))

            elif mode == "chained_stub":
                chain = list(reversed(cnode.parent_classes)) + [cnode]
                chain_lines = []
                for node in chain:
                    b_str = f"({', '.join(node.bases)})" if node.bases else ""
                    chain_lines.append(f"{comment} [Interface Stub: {node.file_path}]\nclass {node.name}{b_str}:")
                    for m in list(node.methods.values())[:max_methods]:
                        if not m.is_inherited:
                            stub_sig = m.signature + ": ..." if node.language == "python" else m.signature
                            chain_lines.append(f"    {stub_sig}")
                            if m.docstring:
                                chain_lines.append(f'        """{m.docstring}"""')
                blocks.append("\n".join(chain_lines))

            elif mode == "ascii_tree":
                base_str = f" (inherits: {', '.join(cnode.bases)})" if cnode.bases else ""
                lines = [f"{comment} [CSSI Context Tree]"]
                lines.append(f"{comment} └── Class: {cnode.name}{base_str}")
                for m in list(cnode.methods.values())[:max_methods]:
                    prefix = f"inherited from {m.source_class}" if m.is_inherited else "declared"
                    lines.append(f"{comment}     ├── [{prefix}] {m.signature}")
                blocks.append("\n".join(lines))

            elif mode == "schema":
                schema_dict = {
                    "class": cnode.name,
                    "bases": cnode.bases,
                    "file_path": cnode.file_path,
                    "methods": [
                        {
                            "name": m.name,
                            "signature": m.signature,
                            "inherited": m.is_inherited,
                            "source_class": m.source_class,
                        }
                        for m in list(cnode.methods.values())[:max_methods]
                    ],
                }
                blocks.append(f"{comment} [CSSI JSON Schema TypeMap]\n{comment} {json.dumps(schema_dict)}")

        return "\n\n".join(blocks) + "\n\n" if blocks else ""


class CSSIContractBuilder:
    """
    Constructs Context-Aware Syntactic/Semantic Interface Stubs backed by TypedContextTree.
    """

    @staticmethod
    def extract_scope_types(left_context: str) -> List[str]:
        """Identifies target class and interface types from recent assignments and imports."""
        lines = left_context.splitlines()
        recent = lines[-30:] if len(lines) >= 30 else lines
        recent_text = "\n".join(recent)
        cur_line = lines[-1] if lines else ""

        receivers = re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\.", cur_line)
        assigned_types: Dict[str, str] = {}
        for m in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*:\s*([A-Za-z_][A-Za-z0-9_]*)", recent_text):
            assigned_types[m.group(1)] = m.group(2)
        for m in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*=\s*([A-Za-z_][A-Za-z0-9_]*)\s*\(", recent_text):
            assigned_types[m.group(1)] = m.group(2)

        target_types: Set[str] = set()
        for r in receivers:
            if r in assigned_types:
                target_types.add(assigned_types[r])
            elif r and r[0].isupper():
                target_types.add(r)
            else:
                target_types.add(r)

        for m in re.finditer(r"(?:from\s+([A-Za-z0-9_.]+)\s+import\s+([^#\n]+)|import\s+([^#\n]+))", left_context):
            syms = (m.group(2) or m.group(3) or "").replace("(", "").replace(")", "").split(",")
            for s in syms:
                s = s.strip()
                if s and s[0].isupper() and s not in STOP_WORDS:
                    target_types.add(s)

        return list(target_types)

    @classmethod
    def build_tree(
        cls,
        language: str,
        pool_files: List[Dict[str, Any]],
    ) -> TypedContextTree:
        """Parses repository pool files into a TypedContextTree and resolves inheritance."""
        tree = TypedContextTree()
        for pf in pool_files:
            fpath = pf.get("path", "")
            text = pf.get("text", "")
            if language == "python" or fpath.endswith(".py"):
                tree.parse_python_ast(fpath, text)
            else:
                tree.parse_java_regex(fpath, text)
        tree.resolve_inheritance()
        return tree

    @classmethod
    def synthesize_contract(
        cls,
        language: str,
        left_context: str,
        pool_files: List[Dict[str, Any]],
        mode: str = "decorated_stub",
        max_methods_per_class: int = 8,
    ) -> str:
        """
        Synthesizes CSSI contract backed by TypedContextTree with inheritance resolution.
        """
        target_types = cls.extract_scope_types(left_context)
        if not target_types:
            return ""

        tree = cls.build_tree(language, pool_files)
        return tree.linearize(
            target_class_names=target_types,
            mode=mode,
            max_methods=max_methods_per_class,
        )
