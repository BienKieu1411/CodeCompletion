"""
prompt_builder.py - Asymmetric Context Allocator and Prompt Assembler for CADRE
Combines Raw Chunks, Syntactic/Semantic Stubs, and Target Specification Contracts
within an exact token budget.
"""

from collections import defaultdict
from typing import Any, Dict, List, Optional


class PromptBuilder:
    """
    Assembles code completion prompts with multi-channel context hierarchy:
    [Channel A: Coalesced Raw Chunks]
    [Channel B: CSSI Class Stubs]
    [Target API Specification (Attention Banner)]
    [Active File Path + Left Context]
    """

    @staticmethod
    def coalesce_chunks_by_file(
        chunks: List[Dict[str, Any]],
        comment_prefix: str,
    ) -> List[str]:
        """Groups raw chunks by file path and coalesces them with '...' ellipsis separators."""
        chunks_by_file: Dict[str, List[str]] = defaultdict(list)
        for ch in chunks:
            fp = ch.get("file_path") or ch.get("path", "")
            code = ch.get("code") or ch.get("text") or ""
            if fp and code.strip():
                chunks_by_file[fp].append(code.strip())

        coalesced_blocks: List[str] = []
        for fp, code_list in chunks_by_file.items():
            content = "\n...\n".join(code_list)
            coalesced_blocks.append(f"{comment_prefix} file path: {fp}\n{content}\n\n")

        return coalesced_blocks

    @classmethod
    def build_prompt_tokens(
        cls,
        tokenizer: Any,
        language: str,
        current_file_path: str,
        left_context: str,
        retrieved_chunks: Optional[List[Dict[str, Any]]] = None,
        cssi_contract: str = "",
        target_spec_block: str = "",
        max_total_tokens: int = 8000,
        max_cross_file_tokens: int = 3200,
    ) -> List[int]:
        """
        Builds tokenized prompt matching the exact CADRE token hierarchy.
        """
        comment_prefix = "#" if language == "python" else "//"
        path_text = f"{comment_prefix} file path: {current_file_path}\n"
        
        path_ids = tokenizer.encode(path_text, add_special_tokens=False) if tokenizer else []
        left_all_ids = tokenizer.encode(left_context, add_special_tokens=False) if tokenizer else []
        cssi_ids = tokenizer.encode(cssi_contract, add_special_tokens=False) if (cssi_contract and tokenizer) else []
        target_spec_ids = tokenizer.encode(target_spec_block, add_special_tokens=False) if (target_spec_block and tokenizer) else []

        # Budget for raw chunks: total cross-file minus stubs
        used_for_stubs = len(cssi_ids) + len(target_spec_ids)
        allowed_raw = max(0, max_cross_file_tokens - used_for_stubs)

        exemplar_ids: List[int] = []
        if retrieved_chunks and tokenizer:
            blocks = cls.coalesce_chunks_by_file(retrieved_chunks, comment_prefix)
            for b in blocks:
                b_ids = tokenizer.encode(b, add_special_tokens=False)
                if len(exemplar_ids) + len(b_ids) > allowed_raw:
                    break
                exemplar_ids.extend(b_ids)

        cross_ids = exemplar_ids + cssi_ids + target_spec_ids
        allowed_left = max(0, max_total_tokens - len(cross_ids) - len(path_ids))
        left_ids = left_all_ids[-allowed_left:] if allowed_left else []

        final_ids = (cross_ids + path_ids + left_ids)[-max_total_tokens:]
        return final_ids

    @classmethod
    def build_prompt_text(
        cls,
        language: str,
        current_file_path: str,
        left_context: str,
        retrieved_chunks: Optional[List[Dict[str, Any]]] = None,
        cssi_contract: str = "",
        target_spec_block: str = "",
    ) -> str:
        """
        Convenience function for building plain-text prompts (for API-based models like OpenAI).
        """
        comment_prefix = "#" if language == "python" else "//"
        parts: List[str] = []

        if retrieved_chunks:
            blocks = cls.coalesce_chunks_by_file(retrieved_chunks, comment_prefix)
            parts.extend(blocks)

        if cssi_contract:
            parts.append(cssi_contract.strip() + "\n\n")

        if target_spec_block:
            parts.append(target_spec_block.strip() + "\n\n")

        parts.append(f"{comment_prefix} file path: {current_file_path}\n{left_context}")
        return "".join(parts)
