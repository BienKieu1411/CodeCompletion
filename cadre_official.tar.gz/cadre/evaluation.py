"""
evaluation.py - Official Benchmark Evaluation Protocols
Implements Exact Match, Bracket Statement Match (CCEval Java), and Edit Similarity.
"""

import re
from collections import defaultdict
from typing import Any, Dict, List

try:
    from fuzzywuzzy import fuzz
    def cal_edit_sim(p: str, g: str) -> float:
        return float(fuzz.ratio(p.strip(), g.strip()))
except ImportError:
    from difflib import SequenceMatcher
    def cal_edit_sim(p: str, g: str) -> float:
        return SequenceMatcher(None, p.strip(), g.strip()).ratio() * 100.0


def remove_comments(code: str) -> str:
    """Strips line comments (# and //) for clean metric matching."""
    code = re.sub(r"#.*", "", code)
    code = re.sub(r"//.*", "", code)
    return code


def get_bracket_stmt(completion: str) -> str:
    """Extracts statement up to closing delimiter for Java bracket matching."""
    end_idx = None
    for i, ch in enumerate(completion):
        if ch in [";", "}", "{"]:
            end_idx = i
            break
    return completion[:end_idx + 1] if end_idx is not None else completion


def evaluate_completion(
    prediction: str,
    groundtruth: str,
    language: str,
    benchmark_name: str = "",
) -> Dict[str, Any]:
    """
    Evaluates a single prediction against groundtruth according to official benchmark rules.
    """
    gt_clean = remove_comments(groundtruth)
    pred_clean = remove_comments(prediction)

    gt_lines = [l.strip() for l in gt_clean.splitlines() if l.strip()]
    n_target = max(1, len(gt_lines))
    pred_lines = [l.strip() for l in pred_clean.splitlines() if l.strip()][:n_target]

    gt_flat = "".join("".join(gt_lines).split())
    pred_flat = "".join("".join(pred_lines).split())

    prefix_match = int(pred_flat[:len(gt_flat)] == gt_flat and len(gt_flat) > 0)

    if benchmark_name == "cceval_java" or (language == "java" and "cceval" in benchmark_name):
        gt_br = "".join(get_bracket_stmt(gt_clean).split())
        pred_br = "".join(get_bracket_stmt(pred_clean).split())
        em = int(pred_br[:len(gt_br)] == gt_br and len(gt_br) > 0)
    else:
        em = prefix_match

    es = cal_edit_sim(pred_clean, gt_clean)
    return {"em": em, "es": es}


def aggregate_benchmark_metrics(
    records: List[Dict[str, Any]],
    pred_key: str = "completion",
) -> Dict[str, Any]:
    """
    Aggregates metrics per benchmark (handling Repo-Average for repoeval).
    """
    by_bench: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in records:
        bm = r.get("benchmark", "default")
        lang = r.get("language", "python")
        gt = r.get("groundtruth", "")
        pred = r.get(pred_key, "")
        repo = r.get("task_id", "").split("/")[0]

        eval_res = evaluate_completion(pred, gt, lang, benchmark_name=bm)
        by_bench[bm].append({
            "task_id": r.get("task_id", ""),
            "repo": repo,
            "em": eval_res["em"],
            "es": eval_res["es"],
        })

    summary: Dict[str, Any] = {}
    macro_em, macro_es = [], []

    for bm, items in by_bench.items():
        n = len(items)
        if bm.startswith("repoeval"):
            repo_map: Dict[str, List[int]] = defaultdict(list)
            repo_es_map: Dict[str, List[float]] = defaultdict(list)
            for it in items:
                repo_map[it["repo"]].append(it["em"])
                repo_es_map[it["repo"]].append(it["es"])
            b_em = sum(sum(v) / len(v) for v in repo_map.values()) / len(repo_map) * 100.0
            b_es = sum(sum(v) / len(v) for v in repo_es_map.values()) / len(repo_es_map) * 100.0
        else:
            b_em = sum(it["em"] for it in items) / n * 100.0
            b_es = sum(it["es"] for it in items) / n * 100.0

        summary[bm] = {"em": round(b_em, 2), "es": round(b_es, 2), "count": n}
        macro_em.append(b_em)
        macro_es.append(b_es)

    if macro_em:
        summary["macro_mean"] = {
            "em": round(sum(macro_em) / len(macro_em), 2),
            "es": round(sum(macro_es) / len(macro_es), 2),
        }

    return summary
