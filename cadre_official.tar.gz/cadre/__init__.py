"""
CADRE: Context-Aware Dependency Retrieval with Draft-Guided Specification Contracts
Training-free repository context augmentation for Code LLMs.
"""

from .intent_parser import IntentParser
from .spec_resolver import TargetSpecResolver
from .cssi import CSSIContractBuilder
from .prompt_builder import PromptBuilder
from .pipeline import CADREPipeline
from .evaluation import evaluate_completion, aggregate_benchmark_metrics

__version__ = "1.0.0"

__all__ = [
    "CADREPipeline",
    "IntentParser",
    "TargetSpecResolver",
    "CSSIContractBuilder",
    "PromptBuilder",
    "evaluate_completion",
    "aggregate_benchmark_metrics",
]
