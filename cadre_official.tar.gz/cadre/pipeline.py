"""
pipeline.py - CADRE Universal 2-Pass Generation Pipeline
Adapts to ANY baseline retriever (BM25, Dense, RLCoder) and ANY LLM generator
(vLLM, HuggingFace, OpenAI, Anthropic, Ollama).
Incorporates Copy-Protection Safety Gating (Zero Negative Transfer) and
Surgical Target Specification Refinement with Flat Decoupling.
"""

from difflib import SequenceMatcher
from typing import Any, Callable, Dict, List, Optional, Union
from .intent_parser import IntentParser, clean_bpe_text
from .spec_resolver import TargetSpecResolver
from .cssi import CSSIContractBuilder
from .prompt_builder import PromptBuilder


def max_line_similarity(cand_line: str, reference_texts: List[str]) -> float:
    """
    Computes maximum token sequence similarity between candidate completion
    and local context / retrieved chunk lines to detect verbatim copying tasks.
    """
    c = cand_line.strip()
    if len(c) < 6:
        return 0.0
    best = 0.0
    for txt in reference_texts:
        for raw in txt.splitlines():
            s = raw.strip().lstrip("#").lstrip("//").strip()
            if len(s) < 6:
                continue
            if s == c:
                return 1.0
            if min(len(s), len(c)) / max(len(s), len(c)) < 0.65:
                continue
            r = SequenceMatcher(None, c, s).ratio()
            if r > best:
                best = r
    return best


class CADREPipeline:
    """
    Universal, training-free repository context augmentation pipeline.
    
    Wraps:
    - Any generator callable: `generate_fn(prompt: Union[str, List[int]]) -> str`
    - Any tokenizer (HuggingFace AutoTokenizer or None for text-based APIs)
    """

    def __init__(
        self,
        generate_fn: Callable[[Union[str, List[int]]], str],
        tokenizer: Optional[Any] = None,
        max_total_tokens: int = 8000,
        max_cross_file_tokens: int = 3200,
        use_base_cssi: bool = False,
        copy_protect_threshold: float = 0.85,
    ):
        """
        Args:
            generate_fn: Callable that takes prompt string or token ID list and returns completion text.
            tokenizer: HuggingFace tokenizer instance (optional, for token budgeting).
            max_total_tokens: Total token window budget (default 8000).
            max_cross_file_tokens: Budget allocated to cross-file contexts and contracts (default 3200).
            use_base_cssi: Whether to inject class-level CSSI stubs in Pass 1.
            copy_protect_threshold: Threshold above which Pass 1 draft is locked as local copy (default 0.85).
        """
        self.generate_fn = generate_fn
        self.tokenizer = tokenizer
        self.max_total_tokens = max_total_tokens
        self.max_cross_file_tokens = max_cross_file_tokens
        self.use_base_cssi = use_base_cssi
        self.copy_protect_threshold = copy_protect_threshold

    def _assemble_prompt(
        self,
        language: str,
        file_path: str,
        left_context: str,
        retrieved_chunks: Optional[List[Dict[str, Any]]] = None,
        cssi_contract: str = "",
        target_spec_block: str = "",
    ) -> Union[str, List[int]]:
        if self.tokenizer:
            return PromptBuilder.build_prompt_tokens(
                tokenizer=self.tokenizer,
                language=language,
                current_file_path=file_path,
                left_context=left_context,
                retrieved_chunks=retrieved_chunks,
                cssi_contract=cssi_contract,
                target_spec_block=target_spec_block,
                max_total_tokens=self.max_total_tokens,
                max_cross_file_tokens=self.max_cross_file_tokens,
            )
        else:
            return PromptBuilder.build_prompt_text(
                language=language,
                current_file_path=file_path,
                left_context=left_context,
                retrieved_chunks=retrieved_chunks,
                cssi_contract=cssi_contract,
                target_spec_block=target_spec_block,
            )

    def complete(
        self,
        language: str,
        file_path: str,
        left_context: str,
        pool_files: List[Dict[str, Any]],
        retrieved_chunks: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Executes the adaptive 2-pass CADRE completion with Copy-Protection Safety Gating.

        Returns:
            Dictionary containing:
            - 'completion': Final generated code completion
            - 'draft_z0': Pass 1 draft
            - 'target_spec': Target specification injected (if any)
            - 'refined': Boolean indicating if Pass 2 was triggered
            - 'copy_sim': Line similarity score with local reference
            - 'copy_protected': Whether the draft was locked by the safety gate
        """
        # Pass 1: Build base context (with optional base CSSI)
        base_cssi = ""
        if self.use_base_cssi:
            base_cssi = CSSIContractBuilder.synthesize_contract(
                language=language,
                left_context=left_context,
                pool_files=pool_files,
                mode="decorated_stub",
            )

        pass1_prompt = self._assemble_prompt(
            language=language,
            file_path=file_path,
            left_context=left_context,
            retrieved_chunks=retrieved_chunks,
            cssi_contract=base_cssi,
            target_spec_block="",
        )

        draft_z0 = self.generate_fn(pass1_prompt)

        # Step 1: Copy-Protection Safety Check
        clean_draft = clean_bpe_text(draft_z0)
        draft_lines = [l.strip() for l in clean_draft.splitlines() if l.strip()]
        first_line = draft_lines[0] if draft_lines else ""

        chunk_texts = [(c.get("code") or c.get("text") or "") for c in (retrieved_chunks or [])[:6]]
        recent_left = left_context.splitlines()[-80:]
        copy_sim = max_line_similarity(first_line, chunk_texts + recent_left)

        if copy_sim >= self.copy_protect_threshold:
            # Defensive Gate: Exactly preserve local completion (guarantees Zero Negative Transfer)
            return {
                "completion": draft_z0,
                "draft_z0": draft_z0,
                "target_spec": "",
                "refined": False,
                "copy_sim": copy_sim,
                "copy_protected": True,
            }

        # Step 2: Draft Intent Resolution
        receiver, callees, tokens = IntentParser.extract_intent(left_context, draft_z0)

        # Step 3: Resolve Target Specification Contract with Flat Decoupling
        target_spec = TargetSpecResolver.resolve_specification(
            language=language,
            pool_files=pool_files,
            candidate_tokens=tokens,
            receiver=receiver,
            retrieved_chunks=retrieved_chunks,
        )

        if not target_spec:
            return {
                "completion": draft_z0,
                "draft_z0": draft_z0,
                "target_spec": "",
                "refined": False,
                "copy_sim": copy_sim,
                "copy_protected": False,
            }

        # Step 4: Pass 2 Re-generation with Target Specification Contract
        pass2_prompt = self._assemble_prompt(
            language=language,
            file_path=file_path,
            left_context=left_context,
            retrieved_chunks=retrieved_chunks,
            cssi_contract=base_cssi,
            target_spec_block=target_spec,
        )

        final_z1 = self.generate_fn(pass2_prompt)

        return {
            "completion": final_z1,
            "draft_z0": draft_z0,
            "target_spec": target_spec,
            "refined": True,
            "copy_sim": copy_sim,
            "copy_protected": False,
        }
