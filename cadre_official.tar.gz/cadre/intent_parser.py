"""
intent_parser.py - Multi-factor Intent Resolver for CADRE-DraftSpec
Extracts intended receiver objects, callees, and semantic stems from the code prompt and draft.
"""

import re
from typing import List, Optional, Set, Tuple

CALL_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_.]*)\s*\(")
RECEIVER_RE = re.compile(r"([A-Za-z_][A-Za-z0-9_.]*)\.\s*$")

STOP_WORDS: Set[str] = {
    "self", "this", "None", "True", "False", "def", "class", "if", "for", "while",
    "return", "import", "from", "public", "private", "protected", "static", "void",
    "int", "str", "float", "bool", "list", "dict", "set", "super", "try", "except",
    "print", "len", "range", "enumerate", "zip", "open", "close", "read", "write",
    "assert", "in", "is", "not", "and", "or", "new", "null", "case", "break", "continue"
}


def clean_bpe_text(s: str) -> str:
    """Removes common BPE artifact characters like Ġ and Ċ."""
    return s.replace("Ġ", " ").replace("Ċ", "\n")


def strip_method_affixes(name: str) -> str:
    """
    Removes common prefix conventions (get_, set_, is_, has_, check_) to extract
    the core semantic stem for morphological matching.
    """
    s = re.sub(r"^(?:is_|get_|set_|has_|check_|do_)", "", name, flags=re.IGNORECASE)
    s = re.sub(r"^(?:is|get|set|has|check)", "", s)
    return s.lower()


class IntentParser:
    """
    Parses code context and draft completions to identify target APIs.
    """

    @staticmethod
    def extract_intent(
        left_context: str,
        raw_draft: str,
    ) -> Tuple[str, List[str], List[str]]:
        """
        Extracts:
        - receiver: Name of receiver object (e.g. 'messenger' or 'self.prob_layer')
        - candidate_callees: Function/method names attempted in cursor line or draft
        - candidate_tokens: Semantic keyword stems
        """
        lines = left_context.splitlines()
        last_line = lines[-1] if lines else ""
        
        clean_draft = clean_bpe_text(raw_draft)
        draft_lines = [l.strip() for l in clean_draft.splitlines() if l.strip()]
        first_draft_line = draft_lines[0] if draft_lines else ""
        combined_intent = (last_line + " " + first_draft_line).strip()

        # 1. Receiver identification
        m_rec = RECEIVER_RE.search(last_line)
        receiver = m_rec.group(1) if m_rec else ""

        # 2. Extract callee candidates from function call syntax
        calls = [m.group(1).split(".")[-1] for m in CALL_RE.finditer(combined_intent)]
        candidate_callees: List[str] = []
        for c in calls:
            if c not in STOP_WORDS and len(c) >= 3 and c not in candidate_callees:
                candidate_callees.append(c)

        # 3. Extract identifier tokens from draft
        candidate_tokens: List[str] = list(candidate_callees)
        if receiver and receiver not in STOP_WORDS and len(receiver) >= 3:
            candidate_tokens.append(receiver.split(".")[-1])

        draft_words = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", first_draft_line)
        for w in draft_words:
            if len(w) >= 4 and w not in STOP_WORDS and w not in candidate_tokens:
                candidate_tokens.append(w)

        return receiver, candidate_callees, candidate_tokens
